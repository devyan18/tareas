<?php 
  include_once 'apitasks.php';
  $api = new ApiTasks();
  $api->getAllStates();
?>